/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
 */

/**
 * Define Global Variables
 *
 */

/**
 * End Global Variables
 * Start Helper Functions
 *
 */

/**
 * End Helper Functions
 * Begin Main Functions
 *
 */

// build the nav

// Add class 'active' to section when near top of viewport

// Scroll to anchor ID using scrollTO event

/**
 * End Main Functions
 * Begin Events
 *
 */

// Build menu

// Scroll to section on link click

// Set sections as active

// Get important Element
const sections = document.querySelectorAll("section");
const ul = document.getElementById("navbar__list");
const fragment = document.createDocumentFragment();
// create frist function
const func = (function () {
  // bulid loop type .for Each to reapet All sections.
  sections.forEach((elm) => {
    let dataLink = elm.getAttribute("data-nav");
    let anchor = document.createElement("a");
    console.log(anchor);
    let textNod = document.createTextNode(dataLink);
    console.log(textNod);
    let list = document.createElement("li");
    console.log(list);
    anchor.setAttribute("class", "menu__link");
    // bulid Append child
    anchor.appendChild(textNod);
    list.appendChild(anchor);
    // bulid scroll with smooth
    anchor.addEventListener("click", (e) => {
      e.preventDefault();
      elm.scrollIntoView({ behavior: "smooth" });
    });
    //To improve  the performance
    fragment.appendChild(list);
  });
  ul.appendChild(fragment);
})(); // end function

//scond request.................Scroll change background color...................
const scrollFunc = (() => {
  window.addEventListener("scroll", () => {
    sections.forEach((sec) => {
      const destans = sec.getBoundingClientRect();

      if (destans.top > 0 && destans.top < 300) {
        const secnavo = sec.dataset.nav;
        const links = document.querySelectorAll("a");
        sec.classList.add("your-active-class");

        for (let link of links) {
          if (link.innerText == secnavo) {
            console.log(link);
            // link.style.backgroundColor = "red";
            link.classList.add("your-active-link");
          } else {
            // link.style.backgroundColor = "white";

            link.classList.remove("your-active-link");
          }
          //   console.log(link);
        }
      } else {
        sec.classList.remove("your-active-class");
      }
    });
  });
})();

///responsive navigation bar
//selected the parent span
const btn = document.querySelector(".parent_sp");
//print parent span to ensure form it
console.log(btn);
//
const ull = document.querySelector("#navbar__list");
//
console.log(ull);
//
const links = document.querySelectorAll("a.menu__link");
//
console.log(links);

//here! i am used the addEvenlistener to add event for menu when click
btn.addEventListener("click", function () {
  //add class (open_ul) to open or close the mega menu of liks
  ull.classList.toggle("open_ul");
});
//used for loop
for (let k = 0; k < links.length; k++) {
  //
  const a = links[k];
  //
  a.addEventListener("click", () => {
    //
    ull.classList.remove("open_ul");
  });
}
